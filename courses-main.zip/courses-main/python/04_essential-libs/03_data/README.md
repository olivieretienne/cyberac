# Module: General

## Modules

- [Beautifulsoup](01_beautifulsoup.ipynb)
- [Pandas](02_pandas.ipynb)

### How to set up and launch the notebook?

> bash ../../setup.sh