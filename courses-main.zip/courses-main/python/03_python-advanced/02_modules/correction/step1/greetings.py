def say_hello():
    print("Hello")


def say_something(text):
    print(text)
