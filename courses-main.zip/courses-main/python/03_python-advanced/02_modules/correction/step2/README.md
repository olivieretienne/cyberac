# Answers to questions #

```.pyc``` files are compiled versions of modules.<br>
There is no ```main.pyc``` as python only compiles modules.