import greetings

if __name__ == "__main__":
    greetings.say_hello()
    greetings.say_something("good")
