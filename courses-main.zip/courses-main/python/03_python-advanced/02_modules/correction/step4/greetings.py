def say_hello():
    print("Hello")


def say_something(text):
    print(text)


if __name__ == "__main__":
    say_something("Hello World from module")
