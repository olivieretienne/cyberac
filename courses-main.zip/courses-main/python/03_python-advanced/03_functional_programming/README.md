# Functional programming

This course of 2h is composed by one main [notebook](./FProgramming-course.ipynb) that we invite you to open right now
by opening a terminal and running.

```jupyter notebook```

In the term of this course you will know concepts of functionnal programming in python and how it can make your code
simpler and easier to debug.
As a bonus, we also provide a full [TP](./Hacking%20mystery.ipynb) where you will put in practice different concepts of
the course.


