string = reduce(sum_xy, list_of_characters)
string_mine = my_reduce_list(list_of_characters, sum_xy, "")
