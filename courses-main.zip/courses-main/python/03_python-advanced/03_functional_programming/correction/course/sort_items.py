sorted_list_items = sorted(list_items, key=lambda x: -x["value"] / x["weight"])
