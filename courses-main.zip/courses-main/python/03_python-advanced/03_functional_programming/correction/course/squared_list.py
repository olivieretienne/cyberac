squared_list = map(lambda x: x ** 2, l)
