# Procedural way :
squared_list2 = []
for elem in l:
    squared_list2.append(elem ** 2)
