# Module 3: Python Advanced

## Object oriented programming

[Course](01_oo)

## Modules

[Course](02_modules)

## Functional programming

[Course](03_functional_programming)
Guillaume / Manon

## Multi task

[Course](04_threading)
Sebastien

## Database

[Course](05_database_access)
Olivier

