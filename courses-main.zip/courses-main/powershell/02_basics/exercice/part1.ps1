# Get all cmdlet "Get" in your system
# Get the cmdlet to get the current datetime
# Get the all informations of webpage www.airbus.com
# How many running service do you have in your workstation ?
# Find the equivalent of "kill"
# Create an alias to calculator application
# add this alias in your profile
# What is the command "cls" ?
# Modify the windows title of your shell
# Add in your prompt if the user is admin or not
# Create environment variable named "plane" with your favorite
# Search in the registry the sofware installed by Airbus

