# DevSecOps Module

---

- Leader: Guillaume Liverneaux
- Volume: 1h30
- 100% on site
- Course: 0%
- Labs/HandOn: 100%

---

---